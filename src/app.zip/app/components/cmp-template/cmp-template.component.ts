import { Component, Input } from '@angular/core';



@Component({
  selector: 'app-template',
  templateUrl: './cmp-template.component.html',
  styleUrl: './cmp-template.component.scss'
})
export class CmpTemplateComponent{

  
  constructor(
  ) {
  }

  ngOnInit(){
   
    }
  
}
